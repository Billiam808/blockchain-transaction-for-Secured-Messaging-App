/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package messaging;

/**
 *
 * @author Vlad
 */
public class MessagingApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        MainJFrame MainFrame = new MainJFrame();
        MainFrame.setResizable(false);
        MainFrame.setTitle("Secure Messaging App v1.0  [CSCI 4800]");
        MainFrame.setVisible(true);
    }
    
}
